package com.program.reminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

class MainActivity : Activity() {

    private var viewDay = 1
    private val dateFmt = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    private val ru = Locale("ru")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val start = Store.getStart(this)
        if (start != null) {
            viewDay = Store.dayNumber(start, LocalDate.now()).coerceIn(1, Program.days(this).size)
        }
    }

    override fun onResume() {
        super.onResume()
        render()
        Scheduler.scheduleNext(this)
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun text(s: String, sizeSp: Float, bold: Boolean = false, color: Int = Color.parseColor("#212121")): TextView =
        TextView(this).apply {
            this.text = s
            textSize = sizeSp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun render() {
        val start = Store.getStart(this)
        if (start == null) setupScreen() else dayScreen(start)
    }

    // ---------- Экран выбора старта ----------

    private fun setupScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        root.addView(text("Программа на 28 дней", 26f, true))
        root.addView(text(
            "Приложение будет напоминать о каждой задаче в нужное время. " +
                "Первый день программы — понедельник. Когда начнём?", 16f
        ).apply { setPadding(0, dp(12), 0, dp(24)) })

        val today = LocalDate.now()
        val monday = today.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))

        root.addView(Button(this).apply {
            this.text = "С ближайшего понедельника (${monday.format(dateFmt)})"
            setOnClickListener { chooseStart(monday) }
        })
        root.addView(Button(this).apply {
            this.text = "Сегодня (${today.format(dateFmt)})"
            setOnClickListener { chooseStart(today) }
        })
        root.addView(Button(this).apply {
            this.text = "Выбрать дату"
            setOnClickListener {
                DatePickerDialog(this@MainActivity, { _, y, m, d -> chooseStart(LocalDate.of(y, m + 1, d)) },
                    today.year, today.monthValue - 1, today.dayOfMonth).show()
            }
        })
        setContentView(root)
    }

    private fun chooseStart(date: LocalDate) {
        Store.setStart(this, date)
        viewDay = Store.dayNumber(date, LocalDate.now()).coerceIn(1, Program.days(this).size)
        Scheduler.scheduleNext(this)
        render()
        ensurePermissions()
    }

    // ---------- Экран дня ----------

    private fun dayScreen(start: LocalDate) {
        val days = Program.days(this)
        val tasks = days[viewDay - 1]
        val date = start.plusDays((viewDay - 1).toLong())
        val today = LocalDate.now()
        val todayNum = Store.dayNumber(start, today)
        val week = (viewDay - 1) / 7 + 1

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(8))
        }

        root.addView(text("День $viewDay из ${days.size}", 26f, true))
        root.addView(text("Неделя $week · ${Program.weekTitle(this, week)}", 15f, color = Color.parseColor("#616161")))
        val dow = date.dayOfWeek.getDisplayName(TextStyle.FULL, ru)
        val marker = when {
            date == today -> " · сегодня"
            else -> ""
        }
        root.addView(text("${date.format(dateFmt)}, $dow$marker", 15f, color = Color.parseColor("#1565C0")))

        when {
            todayNum < 1 -> root.addView(text("Программа начнётся ${start.format(dateFmt)}", 14f, color = Color.parseColor("#E65100")))
            todayNum > days.size -> root.addView(text("Программа завершена. Отличная работа!", 14f, color = Color.parseColor("#2E7D32")))
        }

        var total = 0
        var done = 0
        for (d in days) for (t in d) {
            total++
            if (Store.isDone(this, t.day, t.index)) done++
        }
        root.addView(text("Общий прогресс: $done из $total задач", 13f, color = Color.parseColor("#757575")).apply {
            setPadding(0, dp(2), 0, dp(8))
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (t in tasks) {
            val label = StringBuilder()
            label.append(if (t.time != null) "%02d:%02d".format(t.time.hour, t.time.minute) else "Весь день")
            if (t.note.isNotEmpty()) label.append(" (").append(t.note).append(")")
            label.append("\n").append(t.text)

            val cb = CheckBox(this).apply {
                this.text = label.toString()
                textSize = 16f
                setPadding(dp(4), dp(10), dp(4), dp(10))
                isChecked = Store.isDone(this@MainActivity, t.day, t.index)
                applyStrike(this)
                setOnCheckedChangeListener { _, checked ->
                    Store.setDone(this@MainActivity, t.day, t.index, checked)
                    applyStrike(this)
                }
            }
            list.addView(cb)
        }
        val scroll = ScrollView(this).apply {
            addView(list)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(scroll)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun navButton(label: String, onClick: () -> Unit) = Button(this).apply {
            this.text = label
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        nav.addView(navButton("‹ Назад") {
            if (viewDay > 1) { viewDay--; render() }
        })
        nav.addView(navButton("Сегодня") {
            viewDay = todayNum.coerceIn(1, days.size); render()
        })
        nav.addView(navButton("Вперёд ›") {
            if (viewDay < days.size) { viewDay++; render() }
        })
        root.addView(nav)

        root.addView(Button(this).apply {
            this.text = "Настройки"
            gravity = Gravity.CENTER
            setOnClickListener { showSettings() }
        })

        setContentView(root)
    }

    private fun applyStrike(cb: CheckBox) {
        cb.paintFlags = if (cb.isChecked) cb.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        else cb.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
        cb.alpha = if (cb.isChecked) 0.5f else 1f
    }

    // ---------- Настройки и разрешения ----------

    private fun showSettings() {
        val items = arrayOf(
            "Проверить уведомление",
            "Разрешения (уведомления и точные будильники)",
            "Изменить дату старта",
            "Сбросить отметки о выполнении"
        )
        AlertDialog.Builder(this)
            .setTitle("Настройки")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        Notifier.post(this, 1, "Проверка", "Напоминания работают. Уведомление пришло.")
                        ensurePermissions()
                    }
                    1 -> ensurePermissions()
                    2 -> {
                        val start = Store.getStart(this) ?: LocalDate.now()
                        DatePickerDialog(this, { _, y, m, d -> chooseStart(LocalDate.of(y, m + 1, d)) },
                            start.year, start.monthValue - 1, start.dayOfMonth).show()
                    }
                    3 -> AlertDialog.Builder(this)
                        .setMessage("Снять все отметки о выполнении?")
                        .setPositiveButton("Сбросить") { _, _ -> Store.resetProgress(this); render() }
                        .setNegativeButton("Отмена", null)
                        .show()
                }
            }
            .show()
    }

    private fun ensurePermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        checkExactAlarm()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        checkExactAlarm()
    }

    private fun checkExactAlarm() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                AlertDialog.Builder(this)
                    .setTitle("Точные напоминания")
                    .setMessage("Чтобы уведомления приходили минута в минуту, разрешите «Будильники и напоминания» для этого приложения.")
                    .setPositiveButton("Открыть настройки") { _, _ ->
                        startActivity(
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                        )
                    }
                    .setNegativeButton("Позже", null)
                    .show()
            }
        }
    }
}
