package com.program.reminder

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.app.Notification
import java.time.LocalDateTime
import java.time.ZoneId

object Notifier {
    private const val CHANNEL_ID = "program_reminders"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Напоминания программы", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Напоминания о задачах 28-дневной программы"
            nm.createNotificationChannel(ch)
        }
    }

    fun post(ctx: Context, id: Int, title: String, text: String) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text.lines().firstOrNull() ?: text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}

object Scheduler {
    /** Ставит один будильник на ближайшую будущую задачу программы. */
    fun scheduleNext(ctx: Context) {
        val start = Store.getStart(ctx) ?: return
        val now = LocalDateTime.now()
        var best: LocalDateTime? = null
        for (dayTasks in Program.days(ctx)) {
            for (t in dayTasks) {
                val time = t.time ?: continue
                val dt = start.plusDays((t.day - 1).toLong()).atTime(time)
                if (dt.isAfter(now) && (best == null || dt.isBefore(best))) best = dt
            }
        }

        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(ctx, best)
        if (best == null) {
            am.cancel(pi)
            return
        }
        val millis = best.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        }
    }

    private fun pendingIntent(ctx: Context, dt: LocalDateTime?): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
        if (dt != null) i.putExtra("when", dt.toString())
        return PendingIntent.getBroadcast(
            ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val whenStr = intent.getStringExtra("when")
        val start = Store.getStart(ctx)
        if (whenStr != null && start != null) {
            val dt = LocalDateTime.parse(whenStr)
            val dayNum = Store.dayNumber(start, dt.toLocalDate())
            val days = Program.days(ctx)
            if (dayNum in 1..days.size) {
                val tasks = days[dayNum - 1]
                val atThisTime = tasks.filter { it.time == dt.toLocalTime() }
                if (atThisTime.isNotEmpty()) {
                    val sb = StringBuilder()
                    for (t in atThisTime) {
                        sb.append("• ").append(t.text)
                        if (t.note.isNotEmpty()) sb.append(" (").append(t.note).append(")")
                        sb.append("\n")
                    }
                    // Первое напоминание дня дополняем правилами «на весь день».
                    val firstTimed = tasks.firstOrNull { it.time != null }?.time
                    if (firstTimed == dt.toLocalTime()) {
                        val allDay = tasks.filter { it.time == null }
                        if (allDay.isNotEmpty()) {
                            sb.append("\nВесь день:\n")
                            for (t in allDay) sb.append("• ").append(t.text).append("\n")
                        }
                    }
                    val hhmm = "%02d:%02d".format(dt.hour, dt.minute)
                    Notifier.post(ctx, dayNum * 10000 + dt.hour * 60 + dt.minute,
                        "$hhmm · День $dayNum из ${days.size}", sb.toString().trim())
                }
            }
        }
        Scheduler.scheduleNext(ctx)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.scheduleNext(ctx)
    }
}
