package com.program.reminder

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.temporal.ChronoUnit

data class Task(
    val day: Int,
    val index: Int,
    val time: LocalTime?,
    val note: String,
    val text: String
)

object Program {
    private var days: List<List<Task>>? = null
    private var weekTitles: Map<Int, String> = emptyMap()

    @Synchronized
    private fun ensureLoaded(ctx: Context) {
        if (days != null) return
        val raw = ctx.assets.open("program.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(raw)

        val wt = root.getJSONObject("weekTitles")
        val titles = HashMap<Int, String>()
        for (key in wt.keys()) titles[key.toInt()] = wt.getString(key)
        weekTitles = titles

        val arr = root.getJSONArray("days")
        val result = ArrayList<List<Task>>()
        for (i in 0 until arr.length()) {
            val d = arr.getJSONObject(i)
            val dayNum = d.getInt("day")
            val ts = d.getJSONArray("tasks")
            val list = ArrayList<Task>()
            for (j in 0 until ts.length()) {
                val t = ts.getJSONObject(j)
                val time = if (t.isNull("time")) null else LocalTime.parse(t.getString("time"))
                list.add(Task(dayNum, j, time, t.optString("note", ""), t.getString("text")))
            }
            result.add(list)
        }
        days = result
    }

    fun days(ctx: Context): List<List<Task>> {
        ensureLoaded(ctx)
        return days!!
    }

    fun weekTitle(ctx: Context, week: Int): String {
        ensureLoaded(ctx)
        return weekTitles[week] ?: ""
    }
}

object Store {
    private const val PREFS = "program_prefs"
    private const val KEY_START = "start_epoch_day"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getStart(ctx: Context): LocalDate? {
        val p = prefs(ctx)
        return if (p.contains(KEY_START)) LocalDate.ofEpochDay(p.getLong(KEY_START, 0L)) else null
    }

    fun setStart(ctx: Context, date: LocalDate) {
        prefs(ctx).edit().putLong(KEY_START, date.toEpochDay()).apply()
    }

    fun isDone(ctx: Context, day: Int, index: Int): Boolean =
        prefs(ctx).getBoolean("done_${day}_$index", false)

    fun setDone(ctx: Context, day: Int, index: Int, value: Boolean) {
        prefs(ctx).edit().putBoolean("done_${day}_$index", value).apply()
    }

    fun resetProgress(ctx: Context) {
        val e = prefs(ctx).edit()
        for (k in prefs(ctx).all.keys) if (k.startsWith("done_")) e.remove(k)
        e.apply()
    }

    /** Номер программы-дня для даты (может быть <1 до старта и >28 после конца). */
    fun dayNumber(start: LocalDate, date: LocalDate): Int =
        ChronoUnit.DAYS.between(start, date).toInt() + 1
}
